from django.conf.urls import include, url
from django.contrib import admin

urlpatterns = [
    url(r'^$', 'spexSite.views.home', name='home'),
]