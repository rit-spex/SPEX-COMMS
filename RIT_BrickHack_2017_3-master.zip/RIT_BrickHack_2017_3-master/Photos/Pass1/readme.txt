This was the best attempt we have had thus far.

This was shortly after brick hack when a member of the
Communications team of RIT SPEX designed his own antenna to test.
