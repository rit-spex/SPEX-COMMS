# RIT_BrickHack_2017_3
BrickHack!
